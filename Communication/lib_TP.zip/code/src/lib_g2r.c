#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <semaphore.h>

//à changer avec le chemin de la librairie
#include "/home/boyer/Bureau/Cesar/julius/include/check.h"
//pour l'utilisation de CHECK_IF
#define DEBUG

char lect_req(char * message, int sockfd, int newsock_idtrain, struct sockaddr * train_addr){
	// Accepte une nouvelle connexion
        newsock_idtrain = accept(sockfd, (struct sockaddr *) &train_addr, &clilen);
        if (newsockfd < 0) {
            perror("Erreur lors de l'acceptation");
            exit(1);
        }

        bzero(message, 256);

        // Lit la requête reçue
        int message_size = sizeof(message);
        n = read(newsock_idtrain, message, message_size-1);
        if (n < 0) {
            perror("Erreur lors de la lecture de la socket");
            exit(1);
        }

        // Extrait le nom de la ressource de la requête
        char *resource_name = strtok(message, " ");
        return resource_name;
}

int verouille_ressource(char * ressource_name){
    // Trouve l'index de la ressource dans la liste des ressources
        int resource_index = -1;
        for (int i = 0; i < NUM_RESOURCES; i++) {
            if (strcmp(resource_name, "resource" + i) == 0) {
                resource_index = i;
                break;
            }
        }

        if (resource_index == -1) {
            // La ressource demandée n'existe pas
            printf("Ressource invalid request: %s\n", buffer);

        // Verrouille la ressource demandée en utilisant le sémaphore approprié
        sem_wait(&resource_semaphores[resource_index]);
        printf("verrouillage de la ressource %d", resource_index);
	}
	return EXIT_SUCCESS;
}     

