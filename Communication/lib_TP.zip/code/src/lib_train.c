#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
//à changer avec le chemin de la librairie
#include "/home/boyer/Bureau/Cesar/julius/include/check.h"
//pour l'utilisation de CHECK_IF
#define DEBUG

unsigned int int_to_hex(int num) {
  return (unsigned int)num;
}



unsigned char * creation_message(int message_type, int id_train, int id_ressource, int accepte){
	printf("Création d'un message de type %d par le train d'id %d \n", message_type, id_train);
	unsigned char* message = (unsigned char*)malloc(7 * sizeof(unsigned char));  // Allocate memory for the message
	switch (message_type){
		case 1:	
			// Convert train_id and resource_id to hex strings and store in message
  			sprintf((char*)message, "%04X%04X%04X",message_type , id_train, id_ressource);	
			break;
		case 2:	
			sprintf((char*)message, "%04X%04X%04X",message_type, id_train, accepte);
			break;
		case 3:
			printf("message de type 3\n");
			sprintf((char*)message, "%04X%04X%04X",message_type , id_train, id_ressource);			
			// il s'agit ici de la ressource libérée par le train
			break;
		case 4:		
			sprintf((char*)message, "%04X%04X%04X",message_type , id_train, id_ressource);	
			break;
		default:
			
			printf("Pas le bon type de message");
			exit(EXIT_FAILURE);
		}
	return(message);
}

void afficher_trame(unsigned char * trame) {
    printf("Hex message: %s\n", trame);
}		

